﻿using System;
using System.Collections.Generic;

namespace BookWorm.Data
{
	interface IDataManipulator<T> where T : class, new()
	{
		T[] Select();
		int Insert(T item);
		int Update(T item);
		int Delete(T item);
	}
}