﻿using System;
using BookWorm.Code;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BookWorm.Data
{
	public class SubscriptionDataClient : SqlDataClient<Subscription>
	{
		public SubscriptionDataClient(string connectionString) : base(connectionString) { }

		public override Subscription[] Select()
		{
			return Select("WHERE Username IS NOT NULL AND Url IS NOT NULL");
		}

		public override Subscription[] Select(string constraints, params object[] values)
		{
			string sql = "SELECT * FROM Subscriptions " + constraints;
			List<Subscription> subscriptions = new List<Subscription>();
			using(SqlDataReader reader = ExecuteReader(sql, values))
			using(UserDataClient udc = new UserDataClient(ConnectionString))
			using(BookDataClient bdc = new BookDataClient(ConnectionString))
			{
				while(reader.Read())
				{
					subscriptions.Add(new Subscription()
						{
							User = udc.Select("WHERE Username = @Username", reader["Username"])[0],
							Book = bdc.Select("WHERE Url = @Url", reader["Url"])[0],
							PageNumber = Convert.ToInt32(reader["PageNumber"]),
							Comment = reader["Comment"].ToString()
						});
				}
			}
			return subscriptions.ToArray();
		}

		public override int Insert(Subscription subscription)
		{
			string sql = "";
			sql += "INSERT INTO Subscriptions(Username, Url, PageNumber) VALUES(@Username, @Url, @PageNumber)";
			return ExecuteNonQuery(sql, new object[] { subscription.User.Username, subscription.Book.Url, subscription.PageNumber, subscription.Comment });
		}
		
		public override int Insert(Subscription[] subscriptions)
		{
			int rowsInserted = 0;
			foreach(Subscription subscription in subscriptions)
			{
				rowsInserted += Insert(subscription);
			}
			return rowsInserted;
		}

		public override int Update(Subscription subscription)
		{
			string	sql =  "UPDATE Subscriptions SET PageNumber = @PageNumber, Comment = @Comment ";
					sql += "WHERE Username = @Username AND Url = @Url";
			return ExecuteNonQuery(sql, new object[] { subscription.PageNumber, subscription.Comment, subscription.User.Username, subscription.Book.Url });
		}
		
		public override int Update(Subscription[] subscriptions)
		{
			int rowsUpdated = 0;
			foreach(Subscription subscription in subscriptions)
			{
				rowsUpdated += Update(subscription);
			}
			return rowsUpdated;
		}

		public override int Delete(Subscription subscription)
		{
			string	sql =  "DELETE FROM Subscriptions ";
					sql += "WHERE Username = @Username AND Url = @Url";
			return ExecuteNonQuery(sql, new object[] { subscription.User.Username, subscription.Book.Url });
		}
		
		public override int Delete(Subscription[] subscriptions)
		{
			int rowsDeleted = 0;
			foreach(Subscription subscription in subscriptions)
			{
				rowsDeleted += Delete(subscription);
			}
			return rowsDeleted;
		}
	}
}
