﻿using System;
using System.Data.SqlClient;

namespace BookWorm.Data
{
	public abstract class SqlDataClient<T> : IDataManipulator<T>, IDisposable where T : class, new()
	{
		private SqlConnection _connection;
		private SqlCommand _command;

		private void _InitializeConnection(string connectionString)
		{
			if(_connection == null)
			{
				_connection = new SqlConnection(connectionString);
			}
			_connection.Open();
			_command = _connection.CreateCommand();
		}

		public SqlDataClient(string connectionString)
		{
			_InitializeConnection(connectionString);
		}

		public string ConnectionString
		{
			get
			{
				return _connection.ConnectionString;
			}
			set
			{
				_InitializeConnection(value);
			}
		}

		protected virtual void SetCommandParameters(string sql, object[] values)
		{
			if(values == null)
			{
				return;
			}
			_command.Parameters.Clear();
			for(int i = 0, pos = 0; i < sql.Length - 1 && pos < values.Length; i++)
			{
				if(sql[i] == '@' && char.IsLetterOrDigit(sql[i + 1]))
				{
					string parameter = "@" + sql[++i];
					while(++i < sql.Length && char.IsLetterOrDigit(sql[i]))
					{
						parameter += sql[i];
					}
					if(!_command.Parameters.Contains(parameter))
					{
						_command.Parameters.AddWithValue(parameter, values[pos++]);
					}
				}
			}
		}

		public abstract T[] Select();
		public abstract T[] Select(string constraints, params object[] values);
		public abstract int Insert(T item);
		public abstract int Insert(T[] item);
		public abstract int Update(T item);
		public abstract int Update(T[] item);
		public abstract int Delete(T item);
		public abstract int Delete(T[] item);

		public void Dispose()
		{
			_command.Dispose();
			_connection.Dispose();
		}

		protected SqlDataReader ExecuteReader(string sql, object[] values = null)
		{
			_command.CommandText = sql;
			SetCommandParameters(sql, values);
			SqlDataReader reader = _command.ExecuteReader();
			return reader;
		}

		protected int ExecuteNonQuery(string sql, object[] values = null)
		{
			_command.CommandText = sql;
			SetCommandParameters(sql, values);
			return _command.ExecuteNonQuery();
		}
	}
}
