﻿using System;
using BookWorm.Code;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BookWorm.Data
{
	public class BookDataClient : SqlDataClient<Book>
	{
		public BookDataClient(string connectionString) : base(connectionString) { }

		public override Book[] Select()
		{
			return Select("WHERE Url IS NOT NULL");
		}

		public override Book[] Select(string constraints, params object[] values)
		{
			string sql = "SELECT * FROM Books " + constraints;
			List<Book> books = new List<Book>();
			using(SqlDataReader reader = ExecuteReader(sql, values))
			{
				while(reader.Read())
				{
					books.Add(new Book(reader["Url"].ToString(), reader["Title"].ToString()));
				}
			}
			return books.ToArray();
		}

		public override int Insert(Book book)
		{
			string sql = "INSERT INTO Books(Url, Title) VALUES(@Url, @Title)";
			return ExecuteNonQuery(sql, new object[] { book.Url, book.Title });
		}

		public override int Insert(Book[] books)
		{
			int rowsInserted = 0;
			foreach(Book book in books)
			{
				rowsInserted += Insert(book);
			}
			return rowsInserted;
		}

		public override int Update(Book book)
		{
			string sql = "UPDATE Books SET Title = @Title WHERE Url = @Url";
			return ExecuteNonQuery(sql, new object[] { book.Title, book.Url });
		}
		
		public override int Update(Book[] books)
		{
			int rowsUpdated = 0;
			foreach(Book book in books)
			{
				rowsUpdated += Update(book);
			}
			return rowsUpdated;
		}
		
		public override int Delete(Book book)
		{
			string sql = "DELETE FROM Books WHERE Url = @Url";
			return ExecuteNonQuery(sql, new object[] { book.Url });
		}

		public override int Delete(Book[] books)
		{
			int rowsDeleted = 0;
			foreach(Book book in books)
			{
				rowsDeleted += Delete(book);
			}
			return rowsDeleted;
		}
	}
}
