﻿using BookWorm.Code;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BookWorm.Data
{
	public sealed class UserDataClient : SqlDataClient<User>
	{
		public UserDataClient(string connectionString) : base(connectionString) { }

		private object[] GetUserProperties(User user)
		{
			return new object[]
				{
					user.Username,
					user.Password,
					user.FirstName,
					user.LastName, 
					user.Email,
					user.JoiningTime
				};
		}

		public override User[] Select()
		{
			return Select("WHERE Username IS NOT NULL");
		}

		public override User[] Select(string constraints, params object[] values)
		{
			string sql = "SELECT * FROM Users " + constraints;
			List<User> users = new List<User>();
			using(SqlDataReader reader = ExecuteReader(sql, values))
			{
				while(reader.Read())
				{
					users.Add(new User
						(
							reader["Username"].ToString(),
							reader["Password"].ToString(),
							reader["FirstName"].ToString(),
							reader["LastName"].ToString(),
							reader["Email"].ToString(),
							Convert.ToDateTime(reader["JoiningTime"]))
						);
				}
			}
			return users.ToArray();
		}
		
		public override int Insert(User user)
		{
			string sql = "";
			sql += "INSERT INTO Users(Username, Password, FirstName, LastName, Email, JoiningTime) VALUES(";
			sql += "@Username,";
			sql += "@Password,";
			sql += "@FirstName,";
			sql += "@LastName,";
			sql += "@Email,";
			sql += "@JoiningTime)";
			return ExecuteNonQuery(sql, GetUserProperties(user));
		}

		public override int Insert(User[] users)
		{
			int rowsInserted = 0;
			foreach(User user in users)
			{
				rowsInserted += Insert(user);
			}
			return rowsInserted;
		}

		public override int Update(User user)
		{
			string sql = "";
			sql += "UPDATE Users SET ";
			sql += "Username = @Username,";
			sql += "Password = @Password,";
			sql += "FirstName = @FirstName,";
			sql += "LastName = @LastName,";
			sql += "Email = @Email ";
			sql += "WHERE Username = @Username";
			return ExecuteNonQuery(sql, GetUserProperties(user));
		}

		public override int Update(User[] users)
		{
			int rowsUpdated = 0;
			foreach(User user in users)
			{
				rowsUpdated += Update(user);
			}
			return rowsUpdated;
		}
		
		public override int Delete(User user)
		{
			string sql = "DELETE FROM Users WHERE Username = @Username";
			return ExecuteNonQuery(sql, GetUserProperties(user));
		}

		public override int Delete(User[] users)
		{
			int rowsDeleted = 0;
			foreach(User user in users)
			{
				rowsDeleted += Delete(user);
			}
			return rowsDeleted;
		}
	}
}
