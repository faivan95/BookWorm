﻿using System;
using BookWorm.Code;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BookWorm.Data
{
	public class PublicationDataClient : SqlDataClient<Publication>
	{
		public PublicationDataClient(string connectionString) : base(connectionString) { }

		public override Publication[] Select()
		{
			return Select("WHERE Id IS NOT NULL");
		}

		public override Publication[] Select(string constraints, params object[] values)
		{
			string sql = "SELECT * FROM Publications " + constraints;
			List<Publication> publications = new List<Publication>();
			using(SqlDataReader reader = ExecuteReader(sql, values))
			using(BookDataClient bdc = new BookDataClient(ConnectionString))
			using(AuthorDataClient adc = new AuthorDataClient(ConnectionString))
			{
				while(reader.Read())
				{
					publications.Add(new Publication()
						{
							Id = Convert.ToInt32(reader["Id"]),
							Book = bdc.Select("WHERE Url = @Url", reader["Url"])[0],
							Author = adc.Select("WHERE Id = @Id", reader["AuthorId"])[0]
						});
				}
			}
			return publications.ToArray();
		}

		public override int Insert(Publication publication)
		{
			string sql = "INSERT INTO Publications(Url, AuthorId) VALUES(@Url, @AuthorId)";
			return ExecuteNonQuery(sql, new object[] { publication.Book.Url, publication.Author.Id });
		}
		
		public override int Insert(Publication[] publications)
		{
			int rowsInserted = 0;
			foreach(Publication publication in publications)
			{
				rowsInserted += Insert(publication);
			}
			return rowsInserted;
		}

		public override int Update(Publication publication)
		{
			string sql = "UPDATE Publications SET Url = @Url, AuthorId = @AuthorId WHERE Id = @Id";
			return ExecuteNonQuery(sql, new object[] { publication.Book.Url, publication.Author.Id, publication.Id });
		}
		
		public override int Update(Publication[] publications)
		{
			int rowsUpdated = 0;
			foreach(Publication publication in publications)
			{
				rowsUpdated += Update(publication);
			}
			return rowsUpdated;
		}
		
		public override int Delete(Publication publication)
		{
			string sql = "DELETE FROM Publication WHERE Id = @Id";
			return ExecuteNonQuery(sql, new object[] { publication.Id });
		}
		
		public override int Delete(Publication[] publications)
		{
			int rowsDeleted = 0;
			foreach(Publication publication in publications)
			{
				rowsDeleted += Delete(publication);
			}
			return rowsDeleted;
		}
	}
}
