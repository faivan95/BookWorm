﻿using BookWorm.Code;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookWorm.Data
{
	public class AuthorDataClient : SqlDataClient<Author>
	{
		public AuthorDataClient(string connectionString) : base(connectionString) { }

		public override Author[] Select()
		{
			return Select("WHERE Id IS NOT NULL");
		}

		public override Author[] Select(string constraints, params object[] values)
		{
			string sql = "SELECT * FROM Authors " + constraints;
			List<Author> authors = new List<Author>();
			using(SqlDataReader reader = ExecuteReader(sql, values))
			{
				while(reader.Read())
				{
					authors.Add(new Author
						(
							Convert.ToInt32(reader["Id"]),
							Convert.ToString(reader["Name"])
						));
				}
			}
			return authors.ToArray();
		}

		public override int Insert(Author author)
		{
			string sql = "";
			sql += "INSERT INTO Authors(Name) VALUES(@Name)";
			return ExecuteNonQuery(sql, new object[] { author.Name });
		}

		public override int Insert(Author[] authors)
		{
			int rowsInserted = 0;
			foreach(Author author in authors)
			{
				rowsInserted += Insert(author);
			}
			return rowsInserted;
		}

		public override int Update(Author author)
		{
			string sql = "";
			sql += "UPDATE Authors SET Name = @Name WHERE Id = @Id";
			return ExecuteNonQuery(sql, new object[] { author.Name, author.Id });
		}

		public override int Update(Author[] authors)
		{
			int rowsUpdated = 0;
			foreach(Author author in authors)
			{
				rowsUpdated += Update(author);
			}
			return rowsUpdated;
		}

		public override int Delete(Author author)
		{
			string sql = "DELETE FROM Authors WHERE Id = @Id";
			return ExecuteNonQuery(sql, new object[] { author.Id });
		}

		public override int Delete(Author[] authors)
		{
			int rowsDeleted = 0;
			foreach(Author author in authors)
			{
				rowsDeleted += Delete(author);
			}
			return rowsDeleted;
		}
	}
}
