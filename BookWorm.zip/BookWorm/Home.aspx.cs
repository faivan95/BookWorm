﻿using BookWorm.Code;
using BookWorm.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Web.UI.WebControls;

namespace BookWorm
{
	public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
			if(!IsPostBack)
			{
				if(Session["User"] != null)
				{
					User user = (User)Session["User"];
					Label1.Text = user.Username;
					try
					{
						string connectionString = ConfigurationManager.ConnectionStrings["BookWorm"].ToString();
						using(BookDataClient bdc = new BookDataClient(connectionString))
						using(SubscriptionDataClient sdc = new SubscriptionDataClient(connectionString))
						{
							Label1.Text = ((User)Session["User"]).Username;
							GridView1.DataSource = bdc.Select();
							GridView1.DataBind();
							List<Book> books = new List<Book>();
							foreach(Subscription subscription in sdc.Select("WHERE Username = @Username", ((User)Session["User"]).Username))
							{
								books.Add(subscription.Book);
							}
							GridView2.DataSource = books;
							GridView2.DataBind();
						}
					}
					catch(Exception ex)
					{
						Response.Write("<pre>" + ex + "</pre>");
					}
				}
				else
				{
					Response.Redirect("~/Start.aspx");
				}
			}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
			Session["CurrentUrl"] = TextBox1.Text;
            Response.Redirect("~/BookUpload.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["User"] = null;
            Response.Redirect("~/Start.aspx");
        }

		protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			Response.Redirect("~/BookViewer.aspx?Book=" + Server.UrlEncode(e.CommandName));
		}
	}
}