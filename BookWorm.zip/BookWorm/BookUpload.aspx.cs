﻿using BookWorm.Code;
using BookWorm.Data;
using System;
using System.Configuration;
using System.Web.UI.WebControls;

namespace BookWorm
{
	public partial class BookUpload : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (AuthorDataClient adc = new AuthorDataClient(ConfigurationManager.ConnectionStrings["BookWorm"].ToString()))
                {
                    Author[] authors = adc.Select();
                    CheckBoxList1.DataSource = authors;
                    CheckBoxList1.DataBind();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
			string connectionString = ConfigurationManager.ConnectionStrings["BookWorm"].ToString();
			try
			{
				using(PublicationDataClient pdc = new PublicationDataClient(connectionString))
				using(BookDataClient bdc = new BookDataClient(connectionString))
				using(AuthorDataClient adc = new AuthorDataClient(connectionString))
				{
					Book book = new Book(Session["CurrentUrl"].ToString(), TextBox1.Text);
					bdc.Insert(book);
					Publication publication = new Publication() { Book = book};
					foreach(ListItem item in CheckBoxList1.Items)
					{
						if(item.Selected)
						{
							publication.Author = adc.Select("WHERE Name = @Name", item.Text)[0];
							pdc.Insert(publication);
						}
					}
				}
			}
			catch(Exception ex)
			{
				Response.Write("<pre>" + ex + "</pre>");
			}
            Response.Redirect("~/Home.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }
    }
}