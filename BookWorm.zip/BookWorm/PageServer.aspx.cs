﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Specialized;
using System.IO;

namespace BookWorm
{
	public partial class PageServer : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			NameValueCollection queryString = Request.QueryString;
			if(queryString["Book"] != null && queryString["PageNumber"] != null)
			{
				int pageNumber = int.Parse(queryString["PageNumber"]);
				string fileName = queryString["Book"] + ".pdf";
				string fullPathToFile = Path.Combine(Server.MapPath("~"), "Books", fileName);
				Response.Clear();
				using(PdfReader reader = new PdfReader(fullPathToFile))
				{
					if(pageNumber <= reader.NumberOfPages)
					{
						Response.ContentType = "application/pdf";
						PdfWriter writer = null;
						using(Document document = new Document())
						{
							writer = PdfWriter.GetInstance(document, Response.OutputStream);
							document.Open();
							document.NewPage();
							PdfImportedPage importedPage = writer.GetImportedPage(reader, pageNumber);
							writer.DirectContent.AddTemplate(importedPage, 0, 0);
						}
						writer.Dispose();
					}
				}
				Response.Flush();
			}
		}
	}
}