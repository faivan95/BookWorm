﻿using BookWorm.Code;
using BookWorm.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookWorm
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
			Label1.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            User user = new User()
				{
					Username = TextBox1.Text,
					Password = TextBox2.Text,
					FirstName = TextBox3.Text,
					LastName = TextBox4.Text,
					Email = TextBox5.Text,
					JoiningTime = DateTime.Now
				};
			try
			{
				using(UserDataClient ucs = new UserDataClient(ConfigurationManager.ConnectionStrings["BookWorm"].ToString()))
				{
					ucs.Insert(user);
					Label1.Visible = false;
					Response.Redirect("~/Start.aspx");
				}
			}
			catch(Exception ex)
			{
				Label1.Visible = true;
			}
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Start.aspx");
        }
    }
}