﻿using BookWorm.Code;
using BookWorm.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookWorm
{
	public partial class Start : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if(!IsPostBack)
			{
				string connectionString = ConfigurationManager.ConnectionStrings["BookWorm"].ToString();
				Label5.Visible = false;
				Label6.Visible = false;
				MultiView1.ActiveViewIndex = 0;
				/*using(PublicationDataClient pdc = new PublicationDataClient(connectionString))
				{
					GridView1.DataSource = pdc.Select();
					GridView1.DataBind();
				}*/
				using(AuthorDataClient adc = new AuthorDataClient(connectionString))
				{
					GridView2.DataSource = GridView4.DataSource = adc.Select();
					GridView2.DataBind();
					GridView4.DataBind();
				}
				using(SubscriptionDataClient sdc = new SubscriptionDataClient(connectionString))
				{
					Dictionary<string, int> popularity = new Dictionary<string, int>();
					foreach(Subscription subscription in sdc.Select())
					{
						if(popularity.ContainsKey(subscription.Book.Title))
						{
							++popularity[subscription.Book.Title];
						}
						else
						{
							popularity[subscription.Book.Title] = 1;
						}
					}
					GridView3.DataSource = popularity.OrderByDescending((pair) => pair.Value).Take(3);
					GridView3.DataBind();
					GridView1.DataSource = popularity.OrderByDescending((pair) => pair.Value).Take(3);
					GridView1.DataBind();
				}
				using(PublicationDataClient pdc = new PublicationDataClient(connectionString))
				{
					Publication[] publications = pdc.Select();
				}
			}
		}

		protected void Button1_Click(object sender, EventArgs e)
		{
			MultiView1.ActiveViewIndex++;
		}

		protected void Button2_Click(object sender, EventArgs e)
		{
			try
			{
				using(UserDataClient udc = new UserDataClient(ConfigurationManager.ConnectionStrings["BookWorm"].ToString()))
				{
					User[] users = udc.Select("WHERE Username = @Username", TextBox1.Text);
					if(users.Length != 0 && users[0].Password == TextBox2.Text)
					{
						Session["User"] = users[0];
						Response.Redirect("~/Home.aspx");
					}
					else
					{
						Label5.Visible = true;
					}
				}
			}
			catch(Exception ex)
			{
				Label6.Visible = true;
			}
		}

		protected void Button3_Click(object sender, EventArgs e)
		{
			Response.Redirect("~/SignUp.aspx");
		}

		protected void Button4_Click(object sender, EventArgs e)
		{
			Response.Redirect("~/SignUp.aspx");
		}
	}
}