﻿using BookWorm.Code;
using BookWorm.Data;
using iTextSharp.text.pdf;
using System;
using System.Configuration;
using System.IO;

namespace BookWorm
{
	public partial class BookViewer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["User"] != null)
            {
				if(!IsPostBack)
				{
					if(Request.QueryString["Book"] != null)
					{
						string connectionString = ConfigurationManager.ConnectionStrings["BookWorm"].ToString();
						User user = (User)Session["User"];
						Label1.Text = user.Username;
						using(SubscriptionDataClient sdc = new SubscriptionDataClient(connectionString))
						using(BookDataClient bdc = new BookDataClient(connectionString))
						{
							Book book = bdc.Select("WHERE Title = @Title", Request.QueryString["Book"])[0];
                            Label2.Text = book.Title;
							Subscription subscription = sdc.Select("WHERE Username = @Username AND Url = @Url", user.Username, book.Url)[0];
							Session["CurrentReadingStatus"] = subscription;
							TextBox2.Text = subscription.Comment;
							Session["PageNumber"] = subscription.PageNumber;
							using(PdfReader reader = new PdfReader(Path.Combine(Server.MapPath("~"), "Books", book.Title + ".pdf")))
							{
								Session["TotalNumberOfPages"] = reader.NumberOfPages;
							}
						}
						ViewBookPageAndSaveUpdates(Convert.ToInt32(Session["PageNumber"]));
					}
					else
					{
						Response.Redirect("~/Home.aspx");
					}
				}
            }
			else
			{
				Response.Redirect("~/Start.aspx");
			}
        }

		private void ViewBookPageAndSaveUpdates(int pageNumber)
		{
			Subscription subscription = (Subscription)Session["CurrentReadingStatus"];
			int numberOfPages = Convert.ToInt32(Session["TotalNumberOfPages"]);
            if(pageNumber < numberOfPages)
			{
				Uri url = Request.Url;
				IFrame1.Src = url.Scheme + "://" + url.Host + ":" + url.Port + "/PageServer.aspx?Book=" + Server.UrlEncode(subscription.Book.Title) + "&" + "PageNumber=" + pageNumber;
				TextBox1.Text = pageNumber.ToString();
				Session["PageNumber"] = subscription.PageNumber = pageNumber;
				using(SubscriptionDataClient sdc = new SubscriptionDataClient(ConfigurationManager.ConnectionStrings["BookWorm"].ToString()))
				{
					sdc.Update(subscription);
				}
			}
		}

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Session["User"] = null;
            Response.Redirect("~/Start.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
			int pageNumber = Convert.ToInt32(Session["PageNumber"]);
			ViewBookPageAndSaveUpdates(++pageNumber);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int pageNumber = Convert.ToInt32(Session["PageNumber"]);
			ViewBookPageAndSaveUpdates(--pageNumber);
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            int pageNumber = Convert.ToInt32(TextBox1.Text);
			ViewBookPageAndSaveUpdates(pageNumber);
        }

		protected void TextBox2_TextChanged(object sender, EventArgs e)
		{
			using(SubscriptionDataClient sdc = new SubscriptionDataClient(ConfigurationManager.ConnectionStrings["BookWorm"].ToString()))
			{
				Subscription subscription = (Subscription)Session["CurrentReadingStatus"];
				subscription.Comment = TextBox2.Text;
				sdc.Update(subscription);
			}
		}
	}
}