CREATE DATABASE BookWorm

GO

USE BookWorm

GO

CREATE TABLE Users
(
	Username VARCHAR(15),
	Password VARCHAR(20) NOT NULL,
	FirstName VARCHAR(15),
	LastName VARCHAR(15),
	Email VARCHAR(50),
	JoiningTime DATETIME,
	CONSTRAINT PK_Users PRIMARY KEY (Username)
)

GO

INSERT INTO Users VALUES('ivan404', '#password', 'Ivan', '', 'habijabi@kisuekta.com', '2013-08-30 19:05:00')

GO

CREATE TABLE Authors
(
	Id INT IDENTITY(1, 1),
	Name VARCHAR(50),
	CONSTRAINT PK_Authors PRIMARY KEY (Id)
)

GO

INSERT INTO Authors VALUES('Max Bramer')

GO

CREATE TABLE Books
(
	Url VARCHAR(200),
	Title VARCHAR(50),
	CONSTRAINT PK_Books PRIMARY KEY (Url)
)

GO

INSERT INTO Books VALUES('http://lib.mdp.ac.id/ebook/Karya%20Umum/Data-Mining-Undergraduate-Topics.pdf', 'Principles of Data Mining')

GO

CREATE TABLE Publications
(
	Id INT IDENTITY(1, 1),
	Url VARCHAR(200),
	AuthorId INT,
	CONSTRAINT PK_Publications PRIMARY KEY(Id, Url, AuthorId),
	CONSTRAINT FK_Publications_Books FOREIGN KEY(Url) REFERENCES Books (Url),
	CONSTRAINT FK_Publications_Authors FOREIGN KEY(AuthorId) REFERENCES Authors (Id)
)

GO

INSERT INTO Publications VALUES('http://lib.mdp.ac.id/ebook/Karya%20Umum/Data-Mining-Undergraduate-Topics.pdf', 1)

GO

CREATE TABLE Subscriptions
(
	Username VARCHAR(15),
	Url VARCHAR(200),
	PageNumber INT,
	CONSTRAINT PK_Subscriptions PRIMARY KEY (Username, Url),
	CONSTRAINT FK_Subscriptions_Books FOREIGN KEY (Url) REFERENCES Books (Url),
	CONSTRAINT FK_Subscriptions_Users FOREIGN KEY (Username) REFERENCES Users (Username)
)

GO

INSERT INTO Subscriptions VALUES('ivan404', 'http://lib.mdp.ac.id/ebook/Karya%20Umum/Data-Mining-Undergraduate-Topics.pdf', 1)

GO

ALTER TABLE Subscriptions ADD Comment VARCHAR(300)

GO