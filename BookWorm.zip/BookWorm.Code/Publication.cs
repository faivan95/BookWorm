﻿namespace BookWorm.Code
{
	public class Publication
	{
		public int Id { get; set; }
		public Book Book { get; set; }
		public Author Author { get; set; }
		
		public Publication() : this(0, new Book(), new Author()) { }
		
		public Publication(int id, Book book, Author author)
		{
			Id = id;
			Book = book;
			Author = author;
		}
	}
}