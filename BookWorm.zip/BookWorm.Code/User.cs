﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookWorm.Code
{
    /// <summary>
	/// Represents an entity in table 'Users' in database 'BookWorm'
	/// </summary>
	public class User
    {
		public string Username { get; set; }
		public string Password { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Email { get; set; }
		public DateTime JoiningTime { get; set; }

		/// <summary>
		/// Creates a new User with default values and current DateTime
		/// </summary>
		public User() : this("", "", "", "", "", DateTime.Now) { }
		
		/// <summary>
		/// Creates a new User with supplied values
		/// </summary>
		/// <param name="username"></param>
		/// <param name="password"></param>
		/// <param name="firstName"></param>
		/// <param name="lastName"></param>
		/// <param name="email"></param>
		/// <param name="joiningTime"></param>
		public User(string username,
					string password,
					string firstName,
					string lastName,
					string email,
					DateTime joiningTime)
		{
			Username = username;
			Password = password;
			FirstName = firstName;
			LastName = lastName;
			Email = email;
			JoiningTime = joiningTime;
		}
    }

	public class SomeClass
	{
		
	}
}
