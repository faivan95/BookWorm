﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookWorm.Code
{
	public class Book
	{
		public string Url { get; set; }
		public string Title { get; set; }

		public Book(string url, string title)
		{
			Url = url;
			Title = title;
		}

		public Book()
		{
			Url = Title = "";
		}
	}
}
