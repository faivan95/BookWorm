﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookWorm.Code
{
	public class Subscription
	{
		public User User { get; set; } = new User();
		public Book Book { get; set; } = new Book();
		public int PageNumber { get; set; } = 1;
		public string Comment { get; set; } = "";
		
		public Subscription() { }
		
		public Subscription(User user, Book book, int pageNumber, string comment)
		{
			User = user;
			Book = book;
			PageNumber = pageNumber;
			Comment = comment;
		}
	}
}
